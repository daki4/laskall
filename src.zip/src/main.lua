--package.path = os.getenv("SRC_DIR") .. '/?.lua;' .. package.path

local lskl = require("laskall")
local function divide(x, y)
  if y == 0 then
    return None()
  end
  return Some(x / y)
end

function Main()
  local x = 5;
  local y = 5;

  divide(x, y):match({
    [Some] = function (val)
      print("result: " .. tostring(val))
    end,
    [None] = function ()
      print("got error")
    end
  })
end

local function isEven(x)
  return x % 2 == 0
end

local function doubleEven(x)
  if isEven(x) then
  return x * 2
  end
  return x
end

local function isTriple(x)
  return x % 3 == 0
end
local function quadrupleOdd(x)
  if not isEven(x) then
    return x * 4
  end
  return x
end
pipe(lskl.range(0, 100),
    --ra(filter, isEven),
    ra(lskl.filter, isTriple),
    --ra(lskl.filter, function(x) return not isTriple(x) end),
    --ra(lskl.map, doubleEven),
    --ra(lskl.map, quadrupleOdd),
    ra(lskl.each, print))

Main()
